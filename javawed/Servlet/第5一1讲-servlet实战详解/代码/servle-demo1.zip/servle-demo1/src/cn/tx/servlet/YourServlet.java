package cn.tx.servlet;

import javax.servlet.*;
import java.io.IOException;

/**
 * @author Administrator
 * @title: YourServlet
 * @projectName servle-demo1
 * @description: TODO
 * @date 2019/6/1420:26
 */
public class YourServlet implements Servlet{
    @Override
    public void init(ServletConfig servletConfig) throws ServletException {
        System.out.println("YourServlet被初始化了!!!!");
    }

    @Override
    public ServletConfig getServletConfig() {
        return null;
    }

    @Override
    public void service(ServletRequest servletRequest, ServletResponse servletResponse) throws ServletException, IOException {
        System.out.println("YourServlet处理了客户端请求!!!");
    }

    @Override
    public String getServletInfo() {
        String result = "拓薪教育的Servlet";
        return result;
    }

    @Override
    public void destroy() {
        System.out.println("YourServlet被销毁了!!!");
    }
}
