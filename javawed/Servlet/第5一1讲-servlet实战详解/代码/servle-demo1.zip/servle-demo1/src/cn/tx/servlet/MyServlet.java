package cn.tx.servlet;

import javax.servlet.*;
import java.io.IOException;

/**
 * @author Administrator
 * @title: MyServlet
 * @projectName servle-demo1
 * @description: 实现Serlvet的接口的实现类
 * @date 2019/6/1420:14
 */
public class MyServlet implements Servlet{
    @Override
    public void init(ServletConfig servletConfig) throws ServletException {

    }

    @Override
    public ServletConfig getServletConfig() {
        return null;
    }

    @Override
    public void service(ServletRequest servletRequest, ServletResponse servletResponse) throws ServletException, IOException {
        System.out.println("servlet被调用了!!!");
    }

    @Override
    public String getServletInfo() {
        return null;
    }

    @Override
    public void destroy() {

    }
}
