package cn.tx.servlet;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @author Administrator
 * @title: ${NAME}
 * @projectName servlet-demo3
 * @description: TODO
 * @date 2019/6/1422:00
 */
@WebServlet(name = "Servlet4",urlPatterns = "/s4")
public class Servlet4 extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // 获取ServletContext对象
        ServletContext context = getServletContext();
        // 获取网站的总访问人数 (第一次访问时 获取到的是null)
        Integer count = (Integer) context.getAttribute("count");
        if(count == null){
            count = 0;
        }
        // 把数字加1  然后存入
        count++;
        context.setAttribute("count",count);
        // 向客户端返回响应内容
        response.getWriter().write("count:"+count);
    }
}
