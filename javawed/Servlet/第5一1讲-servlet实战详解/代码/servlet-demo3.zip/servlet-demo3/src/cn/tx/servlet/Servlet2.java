package cn.tx.servlet;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @author Administrator
 * @title: ${NAME}
 * @projectName servlet-demo3
 * @description: TODO
 * @date 2019/6/1422:00
 */
@WebServlet(name = "Servlet2",urlPatterns = "/s2")
public class Servlet2 extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // 获取ServletContext对象
        ServletContext context = getServletContext();
        // 取出内容
        Object company = context.getAttribute("company");
        System.out.println(company);
    }
}
