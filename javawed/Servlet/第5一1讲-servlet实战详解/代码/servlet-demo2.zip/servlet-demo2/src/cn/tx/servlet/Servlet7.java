package cn.tx.servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @author Administrator
 * @title: ${NAME}
 * @projectName servlet-demo2
 * @description: TODO
 * @date 2019/6/1421:42
 */
@WebServlet(name = "Servlet7",urlPatterns = "*.do")
public class Servlet7 extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        System.out.println("Servlet7 被调用了");
    }
}
