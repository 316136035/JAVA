package cn.tx.servlet;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Enumeration;

/**
 * @author Administrator
 * @title: ${NAME}
 * @projectName servlet-demo2
 * @description: TODO
 * @date 2019/6/1421:28
 */
public class Servlet4 extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // 获取ServletConfig
        ServletConfig servletConfig = getServletConfig();
        // 获取该Servlet的初始化参数
        String company = servletConfig.getInitParameter("company");
        System.out.println(company);
        String teacher = servletConfig.getInitParameter("teacher");
        System.out.println(teacher);
        // 获取所有初始化参数的枚举集合
        Enumeration<String> names = servletConfig.getInitParameterNames();
        // 遍历枚举
        while (names.hasMoreElements()){
            // 拿到名称
            String name = names.nextElement();
            String value = servletConfig.getInitParameter(name);
            System.out.println(name + ":" + value);
        }
    }
}
