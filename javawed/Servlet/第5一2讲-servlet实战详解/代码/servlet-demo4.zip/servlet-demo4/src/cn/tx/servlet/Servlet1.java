package cn.tx.servlet;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Enumeration;

/**
 * @author Administrator
 * @title: ${NAME}
 * @projectName servlet-demo4
 * @description: TODO
 * @date 2019/6/1720:05
 */
@WebServlet(name = "Servlet1",urlPatterns = "/context")
public class Servlet1 extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ServletContext context = getServletContext();
        // 获取初始化参数
        String company = context.getInitParameter("company");
        System.out.println(company);


        Object company1 = context.getAttribute("company");
        System.out.println(company1);
        // 获取所有初始化参数名称的集合
        Enumeration<String> names = context.getInitParameterNames();
        // 获取所有的初始化参数的key和value
        while (names.hasMoreElements()){
            String name = names.nextElement();
            System.out.println(name + ":" + context.getInitParameter(name));
        }
    }
}
