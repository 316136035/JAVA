package cn.tx.servlet;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * @author Administrator
 * @title: ${NAME}
 * @projectName servlet-demo4
 * @description: TODO
 * @date 2019/6/1720:18
 */
@WebServlet(name = "Servlet3",urlPatterns = "/tx3")
public class Servlet3 extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Properties p = new Properties();
        ServletContext context = getServletContext();
        // 读取配置文件方法2
        // 直接加载配置文件为输入流
        InputStream stream = context.getResourceAsStream("/WEB-INF/classes/tx.properties");
        p.load(stream);
        System.out.println(p.get("username"));
        System.out.println(p.get("password"));
    }
}
