package cn.tx.servlet;

import java.io.IOException;

/**
 * @author Administrator
 * @title: ${NAME}
 * @projectName ajax-demo
 * @description: TODO
 * @date 2019/6/2420:22
 */
public class Servlet1 extends javax.servlet.http.HttpServlet {
    protected void doPost(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {

    }

    protected void doGet(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
        String id = request.getParameter("id");
        String name = id.equals("1") ? "zhangsan" : "lisi";
        response.getWriter().write(name);
    }
}
