package cn.tx;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import java.util.List;
import java.util.Map;

/**
 * @author Administrator
 * @title: Test2
 * @projectName json-demo
 * @description: TODO
 * @date 2019/6/2421:28
 */
public class Test2 {
    public static void main(String[] args) {
        JSON2Object();
    }

    public static void JSON2Map(){
        String jsonStr = "{\"name\":\"Jack\",\"hasSon\":false,\"Marray\":true,\"age\":90}";
        Map map = JSON.parseObject(jsonStr, Map.class);
        System.out.println(map.get("name"));
        System.out.println(map);
    }

    public static void JSON2Array(){
        String jsonStr = "[\"1\",2,true,8.8,\"123456\"]";
        String jsonStr1 = "[{\"address\":\"北京海淀\",\"gender\":1,\"name\":\"zhangsan\",\"age\":19},{\"address\":\"北京海淀\",\"gender\":1,\"name\":\"liss\",\"age\":20}]";
        List list = JSON.parseObject(jsonStr, List.class);
        System.out.println(list);
        System.out.println(list);



        // 把一个JSON字符串转换成ArrayList  推荐使用这种方式
        List<TxUser> txUsers = JSONArray.parseArray(jsonStr1,TxUser.class);
        txUsers.add(new TxUser("wangwu",29,1,"上海黄浦江"));
        System.out.println(txUsers);
    }

    public static void JSON2Object(){
        String jsonStr = "{\"address\":\"北京海淀\",\"gender\":1,\"name\":\"zhangsan\",\"age\":19}";

        TxUser txUser = JSONObject.parseObject(jsonStr,TxUser.class);
        System.out.println(txUser);
    }
}
