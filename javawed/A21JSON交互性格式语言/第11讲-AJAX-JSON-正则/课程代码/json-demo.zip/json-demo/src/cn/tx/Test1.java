package cn.tx;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Administrator
 * @title: Test1
 * @projectName json-demo
 * @description: TODO
 * @date 2019/6/2421:14
 */
public class Test1 {
    public static void main(String[] args) {
        object2JSON();

    }

    public static void map2JSON(){
        Map<String,Object> map = new HashMap<>();
        map.put("name","Jack");
        map.put("age",90);
        map.put("Marray",true);

        // 把一个JAVA对象转换成JSONObject
        JSONObject jsonObject = (JSONObject) JSON.toJSON(map);
        Object age = jsonObject.get("age");
        System.out.println(age);
        jsonObject.put("hasSon",false);
        System.out.println(jsonObject.toJSONString());
        System.out.println(jsonObject);
    }

    public static void array2JSON(){
        List<TxUser> list = new ArrayList<>();
//        list.add("1");
//        list.add(2);
//        list.add(true);
//        list.add(8.8);
        list.add(new TxUser("zhangsan",19,1,"北京海淀"));
        list.add(new TxUser("liss",20,1,"北京海淀"));

        // 把集合转换成有序列表
        JSONArray jsonArray = (JSONArray) JSONArray.toJSON(list);
        jsonArray.add("123456");
        System.out.println(jsonArray);
    }

    public static void object2JSON(){
        TxUser txUser = new TxUser("zhangsan",19,1,"北京海淀");
        // 把自定义对象 转换成JSON对象
        JSONObject jsonObject = (JSONObject) JSON.toJSON(txUser);
        System.out.println(jsonObject);
    }
}
