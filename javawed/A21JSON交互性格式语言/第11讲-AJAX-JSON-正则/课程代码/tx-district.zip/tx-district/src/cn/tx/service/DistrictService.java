package cn.tx.service;

import com.alibaba.fastjson.JSONArray;

public interface DistrictService {
    JSONArray listDistrict(Integer pId);
}
